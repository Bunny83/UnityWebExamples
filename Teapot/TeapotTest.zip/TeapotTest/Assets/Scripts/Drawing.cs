﻿using System;
using UnityEngine;
using System.Collections.Generic;
//using UnityEditor;

public struct GLGUIRect
{
    private Rect m_Rect;
    public GLGUIRect(Rect aRect)
    {
        var P = GUIUtility.GUIToScreenPoint(new Vector2(aRect.x,aRect.y));
        aRect.x = P.x;
        aRect.y = Screen.height - P.y - aRect.height;
        m_Rect = aRect;
    }

    public static implicit operator Rect(GLGUIRect aObj)
    {
        return aObj.m_Rect;
    }
    public static implicit operator GLGUIRect(Rect aRect)
    {
        return new GLGUIRect(aRect);
    }
}

public static class Drawing
{
    private static Material m_LineMat = null;
	private static Material m_LineMatDepthTest = null;
	private static Mesh m_SimpleQuad = null;
	public static Material m_ActiveMaterial = null;
	
	
	public static Material LineMat
	{
		get
		{
			if (m_LineMat == null)
			{
	            m_LineMat  = new Material("Shader \"Lines/Colored Blended\" {" +
	                                   "SubShader { Pass {" +
	                                   "	BindChannels { Bind \"Color\",color }" +
	                                   "	Blend SrcAlpha OneMinusSrcAlpha" +
	                                   "	ZWrite On Cull Back ZTest Always Fog { Mode Off }" +
	                                   "} } }");
	            m_LineMat.hideFlags = HideFlags.HideAndDontSave;
	            m_LineMat.shader.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_LineMat;
		}
	}
	
	
	
	public static Material LineMatDepthTest
	{
		get
		{
			if (m_LineMatDepthTest == null)
			{
				m_LineMatDepthTest = new Material("Shader \"Lines/Colored Blended with DepthTest\" {" +
	                                   "SubShader { Pass {" +
	                                   "	BindChannels { Bind \"Color\",color }" +
	                                   "	Blend SrcAlpha OneMinusSrcAlpha" +
	                                   "	ZWrite On Cull Back ZTest LEqual Fog { Mode Off }" +
	                                   "} } }");
	            m_LineMatDepthTest.hideFlags = HideFlags.HideAndDontSave;
	            m_LineMatDepthTest.shader.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_LineMatDepthTest;
		}
	}
	
	
	public static Mesh SimpleQuad
	{
		get
		{
			if (m_SimpleQuad == null)
			{
				m_SimpleQuad = new Mesh();
				m_SimpleQuad.vertices   = new Vector3[]{new Vector3(-1,0,-1),new Vector3(-1,0,1),new Vector3(1,0,1),new Vector3(1,0,-1)};
				m_SimpleQuad.uv         = new Vector2[]{new Vector2(0,0)  ,new Vector2(0,1)   ,new Vector2(1,1)  ,new Vector2(1,0)};
				m_SimpleQuad.triangles  = new int[]{0,1,2, 2,3,0};
				m_SimpleQuad.RecalculateNormals();
				m_SimpleQuad.RecalculateBounds();
			}
			return m_SimpleQuad;
		}
	}
	

    public static void GUIViewport(Rect aR)
    {
        var P = GUIUtility.GUIToScreenPoint(new Vector2(aR.x,aR.y));
        aR.x = P.x;
        aR.y = Screen.height - P.y - aR.height;
        GL.Viewport(aR);
        GL.LoadPixelMatrix(0, aR.width, aR.height, 0);
    }
	
    public static void EditorWindowViewport(Rect aWindowRect, Rect aGUIArea)
    {
		aGUIArea.y = aWindowRect.height - aGUIArea.yMax;
        GL.Viewport(aGUIArea);
        GL.LoadPixelMatrix(0, aGUIArea.width, aGUIArea.height, 0);
    }
	
	
    public static void SetViewport(GLGUIRect aR)
    {
        Rect R = aR;
        GL.Viewport(R);
        GL.LoadPixelMatrix(0, R.width, R.height, 0);
    }

    /*
    -+++           4
    ************* 13(9 float +4 vector == 17float)
    */
    private static Vector2 cubeBezier(Vector2 s, Vector2 st, Vector2 e, Vector2 et, float t)
    {
        float rt = 1-t;
        float rtt = rt * t;
        return rt*rt*rt * s + 3 * rt * rtt * st + 3 * rtt * t * et + t*t*t* e;
        //return rt*rt*(rt * s + 3 * t * st) + (3 * rt * et + t * e) *t*t;
    }
    //********** (4 float + 6 Vector == 16 float )
    //-+++       (1 float + 3 vector == 7 float)


    /*
    +-+++-+-+ 9   (18 float additions)
    ******* 7     (14 float mult.)
    */
    private static Vector2 cubeBezier2(Vector2 s, Vector2 st, Vector2 e, Vector2 et, float t)
    {
        return (((-s + 3*(st-et) + e)* t + (3*(s+et) - 6*st))* t + 3*(st-s))* t + s;
    }

    public static Vector3 cubeBezier3(Vector3 s, Vector3 st, Vector3 e, Vector3 et, float t)
    {
        return (((-s + 3*(st-et) + e)* t + (3*(s+et) - 6*st))* t + 3*(st-s))* t + s;
    }

	
	private static Matrix4x4 translationMatrix(Vector3 v)
    {
        return Matrix4x4.TRS(v,Quaternion.identity,Vector3.one);
    }
	
    public static void BeginGL(Color aColor, int aMode)
    {
		BeginGL(aColor, aMode, false);
	}
	
	
    public static void BeginGL(Color aColor, int aMode, bool aDepthTest)
    {
		if (aDepthTest)
			m_ActiveMaterial = LineMatDepthTest;
		else
			m_ActiveMaterial = LineMat;
		m_ActiveMaterial.SetPass(0);
        GL.Begin(aMode);
        GL.Color(aColor);
    }

    public static void DrawGLLine(Vector2 pointA, Vector2 pointB, Color color)
    {
        BeginGL(color,GL.LINES);
        GL.Vertex3(pointA.x,pointA.y,0);
        GL.Vertex3(pointB.x,pointB.y,0);
        GL.End();
    }
    public static void BezierLineGL(Vector2 start, Vector2 startTangent, Vector2 end, Vector2 endTangent, Color color, int segments)
    {
        if (Event.current != null && Event.current.type != EventType.Repaint)
            return;

        Vector2 lastV = cubeBezier(start, startTangent, end, endTangent, 0);
        BeginGL(color,GL.LINES);
        for (int i = 1; i <= segments; ++i)
        {
            Vector2 v = cubeBezier(start, startTangent, end, endTangent, i/(float)segments);
            GL.Vertex3(lastV.x,lastV.y,0);
            GL.Vertex3(v.x,v.y,0);
            lastV = v;
        }
        GL.End();

    }

    public static void BezierLineGL2(Vector2 start, Vector2 startTangent, Vector2 end, Vector2 endTangent, Color color, int segments)
    {
        if (Event.current != null && Event.current.type != EventType.Repaint)
            return;
        Vector2 lastV = cubeBezier2(start, startTangent, end, endTangent, 0);
        BeginGL(color,GL.LINES);
        for (int i = 1; i <= segments; ++i)
        {
            Vector2 v = cubeBezier2(start, startTangent, end, endTangent, i/(float)segments);
            GL.Vertex3(lastV.x,lastV.y,0);
            GL.Vertex3(v.x,v.y,0);
            lastV = v;
        }
        GL.End();
    }

    // Calculates the normalized normal vector (90° clockwise)
    public static Vector2 norm(Vector2 dir)
    {
        Vector2 res = new Vector2(-dir.y,dir.x);
        return res.normalized;
    }

    public static void BezierLineGL(Vector2 start, Vector2 startTangent, Vector2 end, Vector2 endTangent, Color color, int segments,float width)
    {
        if (Event.current != null && Event.current.type != EventType.Repaint)
            return;
        Vector2 lastV = cubeBezier(start, startTangent, end, endTangent, 0);
        BeginGL(color,GL.QUADS);
        Vector2 lastNormal = Vector2.zero;
        for (int i = 1; i <= segments; ++i)
        {
            float stylefactor = 1;//(1-Mathf.Abs(1-(i*2.0f)/(float)segments));
            Vector2 v = cubeBezier(start, startTangent, end, endTangent, i/(float)segments);
            Vector2 normal = norm(v-lastV);
            Vector2 n = (normal + lastNormal).normalized*(width*0.5f*stylefactor);
            if (i == 1 )
            {
                GL.Vertex3(lastV.x + n.x, lastV.y + n.y, 0);
                GL.Vertex3(lastV.x - n.x, lastV.y - n.y, 0);
            }
            if (i == segments)
                n = lastNormal*(width*0.5f*stylefactor);

            GL.Vertex3(v.x-n.x,v.y-n.y,0);
            GL.Vertex3(v.x+n.x,v.y+n.y,0);
            if (i != segments)
            {
                GL.Vertex3(v.x + n.x, v.y + n.y, 0);
                GL.Vertex3(v.x - n.x, v.y - n.y, 0);
            }
            lastV = v;
            lastNormal = normal;
        }
        GL.End();
    }

    public static void DrawRect(Rect R, Color color)
    {
        BeginGL(color,GL.QUADS);
		GL.TexCoord(Vector2.zero);
        GL.Vertex3(R.xMin,R.yMin,0);
        GL.Vertex3(R.xMax,R.yMin,0);
        GL.Vertex3(R.xMax,R.yMax,0);
        GL.Vertex3(R.xMin,R.yMax,0);
        GL.End();
    }
	
	public static IEnumerable<Vector2> GetCirclePoints(Vector2 aCenter, float aRadius, int segments)
	{
		for(int i = 0; i < segments; i++)
		{
			float angle = (float)i / (segments-1) * Mathf.PI*2;
			yield return aCenter + new Vector2(Mathf.Cos(angle)*aRadius, Mathf.Sin(angle)*aRadius);
		}
	}
	public static IEnumerable<Vector2> GetCircleLinePoints(Vector2 aCenter, float aRadius, int segments)
	{
		Vector2 Start = Vector2.zero;
		for(int i = 0; i < segments; i++)
		{
			float angle = (float)i / (segments-1) * Mathf.PI*2;
			Vector2 pos = aCenter + new Vector2(Mathf.Cos(angle)*aRadius, Mathf.Sin(angle)*aRadius); 
			yield return pos;
			if (i == 0)
				Start = pos;
			else
				yield return pos;
		}
		yield return Start;
	}

}