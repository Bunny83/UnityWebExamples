using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class Teapot : MonoBehaviour
{
    #region Teapot data
    public static Vector3[] m_Vertices = new Vector3[]
    {
        new Vector3( 1.40000f, 0.00000f, 2.40000f),    new Vector3( 1.40000f,-0.78400f, 2.40000f),
        new Vector3( 0.78400f,-1.40000f, 2.40000f),    new Vector3( 0.00000f,-1.40000f, 2.40000f),
        new Vector3( 1.33750f, 0.00000f, 2.53125f),    new Vector3( 1.33750f,-0.74900f, 2.53125f),
        new Vector3( 0.74900f,-1.33750f, 2.53125f),    new Vector3( 0.00000f,-1.33750f, 2.53125f),
        new Vector3( 1.43750f, 0.00000f, 2.53125f),    new Vector3( 1.43750f,-0.80500f, 2.53125f),
        new Vector3( 0.80500f,-1.43750f, 2.53125f),    new Vector3( 0.00000f,-1.43750f, 2.53125f),
        new Vector3( 1.50000f, 0.00000f, 2.40000f),    new Vector3( 1.50000f,-0.84000f, 2.40000f),
        new Vector3( 0.84000f,-1.50000f, 2.40000f),    new Vector3( 0.00000f,-1.50000f, 2.40000f),
        new Vector3(-0.78400f,-1.40000f, 2.40000f),    new Vector3(-1.40000f,-0.78400f, 2.40000f),
        new Vector3(-1.40000f, 0.00000f, 2.40000f),    new Vector3(-0.74900f,-1.33750f, 2.53125f),
        new Vector3(-1.33750f,-0.74900f, 2.53125f),    new Vector3(-1.33750f, 0.00000f, 2.53125f),
        new Vector3(-0.80500f,-1.43750f, 2.53125f),    new Vector3(-1.43750f,-0.80500f, 2.53125f),
        new Vector3(-1.43750f, 0.00000f, 2.53125f),    new Vector3(-0.84000f,-1.50000f, 2.40000f),
        new Vector3(-1.50000f,-0.84000f, 2.40000f),    new Vector3(-1.50000f, 0.00000f, 2.40000f),
        new Vector3(-1.40000f, 0.78400f, 2.40000f),    new Vector3(-0.78400f, 1.40000f, 2.40000f),
        new Vector3( 0.00000f, 1.40000f, 2.40000f),    new Vector3(-1.33750f, 0.74900f, 2.53125f),
        new Vector3(-0.74900f, 1.33750f, 2.53125f),    new Vector3( 0.00000f, 1.33750f, 2.53125f),
        new Vector3(-1.43750f, 0.80500f, 2.53125f),    new Vector3(-0.80500f, 1.43750f, 2.53125f),
        new Vector3( 0.00000f, 1.43750f, 2.53125f),    new Vector3(-1.50000f, 0.84000f, 2.40000f),
        new Vector3(-0.84000f, 1.50000f, 2.40000f),    new Vector3( 0.00000f, 1.50000f, 2.40000f),
        new Vector3( 0.78400f, 1.40000f, 2.40000f),    new Vector3( 1.40000f, 0.78400f, 2.40000f),
        new Vector3( 0.74900f, 1.33750f, 2.53125f),    new Vector3( 1.33750f, 0.74900f, 2.53125f),
        new Vector3( 0.80500f, 1.43750f, 2.53125f),    new Vector3( 1.43750f, 0.80500f, 2.53125f),
        new Vector3( 0.84000f, 1.50000f, 2.40000f),    new Vector3( 1.50000f, 0.84000f, 2.40000f),
        new Vector3( 1.75000f, 0.00000f, 1.87500f),    new Vector3( 1.75000f,-0.98000f, 1.87500f),
        new Vector3( 0.98000f,-1.75000f, 1.87500f),    new Vector3( 0.00000f,-1.75000f, 1.87500f),
        new Vector3( 2.00000f, 0.00000f, 1.35000f),    new Vector3( 2.00000f,-1.12000f, 1.35000f),
        new Vector3( 1.12000f,-2.00000f, 1.35000f),    new Vector3( 0.00000f,-2.00000f, 1.35000f),
        new Vector3( 2.00000f, 0.00000f, 0.90000f),    new Vector3( 2.00000f,-1.12000f, 0.90000f),
        new Vector3( 1.12000f,-2.00000f, 0.90000f),    new Vector3( 0.00000f,-2.00000f, 0.90000f),
        new Vector3(-0.98000f,-1.75000f, 1.87500f),    new Vector3(-1.75000f,-0.98000f, 1.87500f),
        new Vector3(-1.75000f, 0.00000f, 1.87500f),    new Vector3(-1.12000f,-2.00000f, 1.35000f),
        new Vector3(-2.00000f,-1.12000f, 1.35000f),    new Vector3(-2.00000f, 0.00000f, 1.35000f),
        new Vector3(-1.12000f,-2.00000f, 0.90000f),    new Vector3(-2.00000f,-1.12000f, 0.90000f),
        new Vector3(-2.00000f, 0.00000f, 0.90000f),    new Vector3(-1.75000f, 0.98000f, 1.87500f),
        new Vector3(-0.98000f, 1.75000f, 1.87500f),    new Vector3( 0.00000f, 1.75000f, 1.87500f),
        new Vector3(-2.00000f, 1.12000f, 1.35000f),    new Vector3(-1.12000f, 2.00000f, 1.35000f),
        new Vector3( 0.00000f, 2.00000f, 1.35000f),    new Vector3(-2.00000f, 1.12000f, 0.90000f),
        new Vector3(-1.12000f, 2.00000f, 0.90000f),    new Vector3( 0.00000f, 2.00000f, 0.90000f),
        new Vector3( 0.98000f, 1.75000f, 1.87500f),    new Vector3( 1.75000f, 0.98000f, 1.87500f),
        new Vector3( 1.12000f, 2.00000f, 1.35000f),    new Vector3( 2.00000f, 1.12000f, 1.35000f),
        new Vector3( 1.12000f, 2.00000f, 0.90000f),    new Vector3( 2.00000f, 1.12000f, 0.90000f),
        new Vector3( 2.00000f, 0.00000f, 0.45000f),    new Vector3( 2.00000f,-1.12000f, 0.45000f),
        new Vector3( 1.12000f,-2.00000f, 0.45000f),    new Vector3( 0.00000f,-2.00000f, 0.45000f),
        new Vector3( 1.50000f, 0.00000f, 0.22500f),    new Vector3( 1.50000f,-0.84000f, 0.22500f),
        new Vector3( 0.84000f,-1.50000f, 0.22500f),    new Vector3( 0.00000f,-1.50000f, 0.22500f),
        new Vector3( 1.50000f, 0.00000f, 0.15000f),    new Vector3( 1.50000f,-0.84000f, 0.15000f),
        new Vector3( 0.84000f,-1.50000f, 0.15000f),    new Vector3( 0.00000f,-1.50000f, 0.15000f),
        new Vector3(-1.12000f,-2.00000f, 0.45000f),    new Vector3(-2.00000f,-1.12000f, 0.45000f),
        new Vector3(-2.00000f, 0.00000f, 0.45000f),    new Vector3(-0.84000f,-1.50000f, 0.22500f),
        new Vector3(-1.50000f,-0.84000f, 0.22500f),    new Vector3(-1.50000f, 0.00000f, 0.22500f),
        new Vector3(-0.84000f,-1.50000f, 0.15000f),    new Vector3(-1.50000f,-0.84000f, 0.15000f),
        new Vector3(-1.50000f, 0.00000f, 0.15000f),    new Vector3(-2.00000f, 1.12000f, 0.45000f),
        new Vector3(-1.12000f, 2.00000f, 0.45000f),    new Vector3( 0.00000f, 2.00000f, 0.45000f),
        new Vector3(-1.50000f, 0.84000f, 0.22500f),    new Vector3(-0.84000f, 1.50000f, 0.22500f),
        new Vector3( 0.00000f, 1.50000f, 0.22500f),    new Vector3(-1.50000f, 0.84000f, 0.15000f),
        new Vector3(-0.84000f, 1.50000f, 0.15000f),    new Vector3( 0.00000f, 1.50000f, 0.15000f),
        new Vector3( 1.12000f, 2.00000f, 0.45000f),    new Vector3( 2.00000f, 1.12000f, 0.45000f),
        new Vector3( 0.84000f, 1.50000f, 0.22500f),    new Vector3( 1.50000f, 0.84000f, 0.22500f),
        new Vector3( 0.84000f, 1.50000f, 0.15000f),    new Vector3( 1.50000f, 0.84000f, 0.15000f),
        new Vector3(-1.60000f, 0.00000f, 2.02500f),    new Vector3(-1.60000f,-0.30000f, 2.02500f),
        new Vector3(-1.50000f,-0.30000f, 2.25000f),    new Vector3(-1.50000f, 0.00000f, 2.25000f),
        new Vector3(-2.30000f, 0.00000f, 2.02500f),    new Vector3(-2.30000f,-0.30000f, 2.02500f),
        new Vector3(-2.50000f,-0.30000f, 2.25000f),    new Vector3(-2.50000f, 0.00000f, 2.25000f),
        new Vector3(-2.70000f, 0.00000f, 2.02500f),    new Vector3(-2.70000f,-0.30000f, 2.02500f),
        new Vector3(-3.00000f,-0.30000f, 2.25000f),    new Vector3(-3.00000f, 0.00000f, 2.25000f),
        new Vector3(-2.70000f, 0.00000f, 1.80000f),    new Vector3(-2.70000f,-0.30000f, 1.80000f),
        new Vector3(-3.00000f,-0.30000f, 1.80000f),    new Vector3(-3.00000f, 0.00000f, 1.80000f),
        new Vector3(-1.50000f, 0.30000f, 2.25000f),    new Vector3(-1.60000f, 0.30000f, 2.02500f),
        new Vector3(-2.50000f, 0.30000f, 2.25000f),    new Vector3(-2.30000f, 0.30000f, 2.02500f),
        new Vector3(-3.00000f, 0.30000f, 2.25000f),    new Vector3(-2.70000f, 0.30000f, 2.02500f),
        new Vector3(-3.00000f, 0.30000f, 1.80000f),    new Vector3(-2.70000f, 0.30000f, 1.80000f),
        new Vector3(-2.70000f, 0.00000f, 1.57500f),    new Vector3(-2.70000f,-0.30000f, 1.57500f),
        new Vector3(-3.00000f,-0.30000f, 1.35000f),    new Vector3(-3.00000f, 0.00000f, 1.35000f),
        new Vector3(-2.50000f, 0.00000f, 1.12500f),    new Vector3(-2.50000f,-0.30000f, 1.12500f),
        new Vector3(-2.65000f,-0.30000f, 0.93750f),    new Vector3(-2.65000f, 0.00000f, 0.93750f),
        new Vector3(-2.00000f,-0.30000f, 0.90000f),    new Vector3(-1.90000f,-0.30000f, 0.60000f),
        new Vector3(-1.90000f, 0.00000f, 0.60000f),    new Vector3(-3.00000f, 0.30000f, 1.35000f),
        new Vector3(-2.70000f, 0.30000f, 1.57500f),    new Vector3(-2.65000f, 0.30000f, 0.93750f),
        new Vector3(-2.50000f, 0.30000f, 1.12500f),    new Vector3(-1.90000f, 0.30000f, 0.60000f),
        new Vector3(-2.00000f, 0.30000f, 0.90000f),    new Vector3( 1.70000f, 0.00000f, 1.42500f),
        new Vector3( 1.70000f,-0.66000f, 1.42500f),    new Vector3( 1.70000f,-0.66000f, 0.60000f),
        new Vector3( 1.70000f, 0.00000f, 0.60000f),    new Vector3( 2.60000f, 0.00000f, 1.42500f),
        new Vector3( 2.60000f,-0.66000f, 1.42500f),    new Vector3( 3.10000f,-0.66000f, 0.82500f),
        new Vector3( 3.10000f, 0.00000f, 0.82500f),    new Vector3( 2.30000f, 0.00000f, 2.10000f),
        new Vector3( 2.30000f,-0.25000f, 2.10000f),    new Vector3( 2.40000f,-0.25000f, 2.02500f),
        new Vector3( 2.40000f, 0.00000f, 2.02500f),    new Vector3( 2.70000f, 0.00000f, 2.40000f),
        new Vector3( 2.70000f,-0.25000f, 2.40000f),    new Vector3( 3.30000f,-0.25000f, 2.40000f),
        new Vector3( 3.30000f, 0.00000f, 2.40000f),    new Vector3( 1.70000f, 0.66000f, 0.60000f),
        new Vector3( 1.70000f, 0.66000f, 1.42500f),    new Vector3( 3.10000f, 0.66000f, 0.82500f),
        new Vector3( 2.60000f, 0.66000f, 1.42500f),    new Vector3( 2.40000f, 0.25000f, 2.02500f),
        new Vector3( 2.30000f, 0.25000f, 2.10000f),    new Vector3( 3.30000f, 0.25000f, 2.40000f),
        new Vector3( 2.70000f, 0.25000f, 2.40000f),    new Vector3( 2.80000f, 0.00000f, 2.47500f),
        new Vector3( 2.80000f,-0.25000f, 2.47500f),    new Vector3( 3.52500f,-0.25000f, 2.49375f),
        new Vector3( 3.52500f, 0.00000f, 2.49375f),    new Vector3( 2.90000f, 0.00000f, 2.47500f),
        new Vector3( 2.90000f,-0.15000f, 2.47500f),    new Vector3( 3.45000f,-0.15000f, 2.51250f),
        new Vector3( 3.45000f, 0.00000f, 2.51250f),    new Vector3( 2.80000f, 0.00000f, 2.40000f),
        new Vector3( 2.80000f,-0.15000f, 2.40000f),    new Vector3( 3.20000f,-0.15000f, 2.40000f),
        new Vector3( 3.20000f, 0.00000f, 2.40000f),    new Vector3( 3.52500f, 0.25000f, 2.49375f),
        new Vector3( 2.80000f, 0.25000f, 2.47500f),    new Vector3( 3.45000f, 0.15000f, 2.51250f),
        new Vector3( 2.90000f, 0.15000f, 2.47500f),    new Vector3( 3.20000f, 0.15000f, 2.40000f),
        new Vector3( 2.80000f, 0.15000f, 2.40000f),    new Vector3( 0.00000f, 0.00000f, 3.15000f),
        new Vector3( 0.00000f,-0.00200f, 3.15000f),    new Vector3( 0.00200f, 0.00000f, 3.15000f),
        new Vector3( 0.80000f, 0.00000f, 3.15000f),    new Vector3( 0.80000f,-0.45000f, 3.15000f),
        new Vector3( 0.45000f,-0.80000f, 3.15000f),    new Vector3( 0.00000f,-0.80000f, 3.15000f),
        new Vector3( 0.00000f, 0.00000f, 2.85000f),    new Vector3( 0.20000f, 0.00000f, 2.70000f),
        new Vector3( 0.20000f,-0.11200f, 2.70000f),    new Vector3( 0.11200f,-0.20000f, 2.70000f),
        new Vector3( 0.00000f,-0.20000f, 2.70000f),    new Vector3(-0.00200f, 0.00000f, 3.15000f),
        new Vector3(-0.45000f,-0.80000f, 3.15000f),    new Vector3(-0.80000f,-0.45000f, 3.15000f),
        new Vector3(-0.80000f, 0.00000f, 3.15000f),    new Vector3(-0.11200f,-0.20000f, 2.70000f),
        new Vector3(-0.20000f,-0.11200f, 2.70000f),    new Vector3(-0.20000f, 0.00000f, 2.70000f),
        new Vector3( 0.00000f, 0.00200f, 3.15000f),    new Vector3(-0.80000f, 0.45000f, 3.15000f),
        new Vector3(-0.45000f, 0.80000f, 3.15000f),    new Vector3( 0.00000f, 0.80000f, 3.15000f),
        new Vector3(-0.20000f, 0.11200f, 2.70000f),    new Vector3(-0.11200f, 0.20000f, 2.70000f),
        new Vector3( 0.00000f, 0.20000f, 2.70000f),    new Vector3( 0.45000f, 0.80000f, 3.15000f),
        new Vector3( 0.80000f, 0.45000f, 3.15000f),    new Vector3( 0.11200f, 0.20000f, 2.70000f),
        new Vector3( 0.20000f, 0.11200f, 2.70000f),    new Vector3( 0.40000f, 0.00000f, 2.55000f),
        new Vector3( 0.40000f,-0.22400f, 2.55000f),    new Vector3( 0.22400f,-0.40000f, 2.55000f),
        new Vector3( 0.00000f,-0.40000f, 2.55000f),    new Vector3( 1.30000f, 0.00000f, 2.55000f),
        new Vector3( 1.30000f,-0.72800f, 2.55000f),    new Vector3( 0.72800f,-1.30000f, 2.55000f),
        new Vector3( 0.00000f,-1.30000f, 2.55000f),    new Vector3( 1.30000f, 0.00000f, 2.40000f),
        new Vector3( 1.30000f,-0.72800f, 2.40000f),    new Vector3( 0.72800f,-1.30000f, 2.40000f),
        new Vector3( 0.00000f,-1.30000f, 2.40000f),    new Vector3(-0.22400f,-0.40000f, 2.55000f),
        new Vector3(-0.40000f,-0.22400f, 2.55000f),    new Vector3(-0.40000f, 0.00000f, 2.55000f),
        new Vector3(-0.72800f,-1.30000f, 2.55000f),    new Vector3(-1.30000f,-0.72800f, 2.55000f),
        new Vector3(-1.30000f, 0.00000f, 2.55000f),    new Vector3(-0.72800f,-1.30000f, 2.40000f),
        new Vector3(-1.30000f,-0.72800f, 2.40000f),    new Vector3(-1.30000f, 0.00000f, 2.40000f),
        new Vector3(-0.40000f, 0.22400f, 2.55000f),    new Vector3(-0.22400f, 0.40000f, 2.55000f),
        new Vector3( 0.00000f, 0.40000f, 2.55000f),    new Vector3(-1.30000f, 0.72800f, 2.55000f),
        new Vector3(-0.72800f, 1.30000f, 2.55000f),    new Vector3( 0.00000f, 1.30000f, 2.55000f),
        new Vector3(-1.30000f, 0.72800f, 2.40000f),    new Vector3(-0.72800f, 1.30000f, 2.40000f),
        new Vector3( 0.00000f, 1.30000f, 2.40000f),    new Vector3( 0.22400f, 0.40000f, 2.55000f),
        new Vector3( 0.40000f, 0.22400f ,2.55000f),    new Vector3( 0.72800f, 1.30000f, 2.55000f),
        new Vector3( 1.30000f, 0.72800f, 2.55000f),    new Vector3( 0.72800f, 1.30000f, 2.40000f),
        new Vector3( 1.30000f, 0.72800f, 2.40000f),    new Vector3( 0.00000f, 0.00000f, 0.00000f),
        new Vector3( 1.50000f, 0.00000f, 0.15000f),    new Vector3( 1.50000f, 0.84000f, 0.15000f),
        new Vector3( 0.84000f, 1.50000f, 0.15000f),    new Vector3( 0.00000f, 1.50000f, 0.15000f),
        new Vector3( 1.50000f, 0.00000f, 0.07500f),    new Vector3( 1.50000f, 0.84000f, 0.07500f),
        new Vector3( 0.84000f, 1.50000f, 0.07500f),    new Vector3( 0.00000f, 1.50000f, 0.07500f),
        new Vector3( 1.42500f, 0.00000f, 0.00000f),    new Vector3( 1.42500f, 0.79800f, 0.00000f),
        new Vector3( 0.79800f, 1.42500f, 0.00000f),    new Vector3( 0.00000f, 1.42500f, 0.00000f),
        new Vector3(-0.84000f, 1.50000f, 0.15000f),    new Vector3(-1.50000f, 0.84000f, 0.15000f),
        new Vector3(-1.50000f, 0.00000f, 0.15000f),    new Vector3(-0.84000f, 1.50000f, 0.07500f),
        new Vector3(-1.50000f, 0.84000f, 0.07500f),    new Vector3(-1.50000f, 0.00000f, 0.07500f),
        new Vector3(-0.79800f, 1.42500f, 0.00000f),    new Vector3(-1.42500f, 0.79800f, 0.00000f),
        new Vector3(-1.42500f, 0.00000f, 0.00000f),    new Vector3(-1.50000f,-0.84000f, 0.15000f),
        new Vector3(-0.84000f,-1.50000f, 0.15000f),    new Vector3( 0.00000f,-1.50000f, 0.15000f),
        new Vector3(-1.50000f,-0.84000f, 0.07500f),    new Vector3(-0.84000f,-1.50000f, 0.07500f),
        new Vector3( 0.00000f,-1.50000f, 0.07500f),    new Vector3(-1.42500f,-0.79800f, 0.00000f),
        new Vector3(-0.79800f,-1.42500f, 0.00000f),    new Vector3( 0.00000f,-1.42500f, 0.00000f),
        new Vector3( 0.84000f,-1.50000f, 0.15000f),    new Vector3( 1.50000f,-0.84000f, 0.15000f),
        new Vector3( 0.84000f,-1.50000f, 0.07500f),    new Vector3( 1.50000f,-0.84000f, 0.07500f),
        new Vector3( 0.79800f,-1.42500f, 0.00000f),    new Vector3( 1.42500f,-0.79800f, 0.00000f),
    };
    public static int[][] m_Patches = new int[][]
    {
        // rim
        new int[] {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16},
        new int[] {4,17,18,19,8,20,21,22,12,23,24,25,16,26,27,28},
        new int[] {19,29,30,31,22,32,33,34,25,35,36,37,28,38,39,40},
        new int[] {31,41,42,1,34,43,44,5,37,45,46,9,40,47,48,13},
        // upper body
        new int[] {13,14,15,16,49,50,51,52,53,54,55,56,57,58,59,60},
        new int[] {16,26,27,28,52,61,62,63,56,64,65,66,60,67,68,69},
        new int[] {28,38,39,40,63,70,71,72,66,73,74,75,69,76,77,78},
        new int[] {40,47,48,13,72,79,80,49,75,81,82,53,78,83,84,57},
        // lower body
        new int[] {57,58,59,60,85,86,87,88,89,90,91,92,93,94,95,96},
        new int[] {60,67,68,69,88,97,98,99,92,100,101,102,96,103,104,105},
        new int[] {69,76,77,78,99,106,107,108,102,109,110,111,105,112,113,114},
        new int[] {78,83,84,57,108,115,116,85,111,117,118,89,114,119,120,93},
        // handle
        new int[] {121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136},
        new int[] {124,137,138,121,128,139,140,125,132,141,142,129,136,143,144,133},
        new int[] {133,134,135,136,145,146,147,148,149,150,151,152,69,153,154,155},
        new int[] {136,143,144,133,148,156,157,145,152,158,159,149,155,160,161,69},
        // lower Spout
        new int[] {162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177},
        new int[] {165,178,179,162,169,180,181,166,173,182,183,170,177,184,185,174},
        // upper Spout
        new int[] {174,175,176,177,186,187,188,189,190,191,192,193,194,195,196,197},
        new int[] {177,184,185,174,189,198,199,186,193,200,201,190,197,202,203,194},
        // lid handle
        new int[] {204,204,204,204,207,208,209,210,211,211,211,211,212,213,214,215},
        new int[] {204,204,204,204,210,217,218,219,211,211,211,211,215,220,221,222},
        new int[] {204,204,204,204,219,224,225,226,211,211,211,211,222,227,228,229},
        new int[] {204,204,204,204,226,230,231,207,211,211,211,211,229,232,233,212},
        // lid
        new int[] {212,213,214,215,234,235,236,237,238,239,240,241,242,243,244,245},
        new int[] {215,220,221,222,237,246,247,248,241,249,250,251,245,252,253,254},
        new int[] {222,227,228,229,248,255,256,257,251,258,259,260,254,261,262,263},
        new int[] {229,232,233,212,257,264,265,234,260,266,267,238,263,268,269,242},
        // bottom
        new int[] {270,270,270,270,279,280,281,282,275,276,277,278,271,272,273,274},
        new int[] {270,270,270,270,282,289,290,291,278,286,287,288,274,283,284,285},
        new int[] {270,270,270,270,291,298,299,300,288,295,296,297,285,292,293,294},
        new int[] {270,270,270,270,300,305,306,279,297,303,304,275,294,301,302,271}
    };
    #endregion Teapot data
    public class PartConfig
    {
        public string Name;
        public int[] patches;
        public PartConfig(string aName, params int[] aPatches)
        {
            Name = aName;
            patches = aPatches;
        }
    }
    public static PartConfig[] config = new PartConfig[]
    {
        new PartConfig("lid handle",20,21,22,23),
        new PartConfig("lid",24,25,26,27),
        new PartConfig("rim",0,1,2,3),
        new PartConfig("upper body",4,5,6,7),
        new PartConfig("handle",12,13,14,15),
        new PartConfig("spout",16,17,18,19),
        new PartConfig("lower body",8,9,10,11),
        new PartConfig("bottom",28,29,30,31),
    };

    public enum RotateMode {None, Teapot, Light}
    System.Action drawQuadsWireframe = () => {};
    int vertCount = 0;
    int quadCount = 0;

    public uint patchesVisible = uint.MaxValue;
    
    public int uCount = 16;
    public int vCount = 16;
    public GUISkin skin;
    public Transform directionalLight;
    public List<Material> materials;

    Camera cam;
    MeshRenderer rend;

    int oldU =16;
    int oldV = 16;
    uint oldPatchesVisible = uint.MaxValue;
    RotateMode rotate = RotateMode.None;
    bool m_WireFrame = true;
    bool m_ShowControlPoints = false;
	
    void Start()
    {
        cam = Camera.main;
        rend = GetComponent<MeshRenderer>();
        if (rend == null)
            rend = gameObject.AddComponent<MeshRenderer>();
        //max = m_Patches.Length;
        GenerateTeapot(uCount, vCount);
        materials.Add(Drawing.LineMatDepthTest);
    }
    public Vector3 Fix(Vector3 aVec)
    {
        return new Vector3(aVec.x, aVec.z, -aVec.y);
    }

    public void GenerateTeapot(int aUCount, int aVCount)
    {
        var MF = gameObject.GetComponent<MeshFilter>();
        if (MF == null)
            MF = gameObject.AddComponent<MeshFilter>();
        var m = MF.sharedMesh = new Mesh();

        List<Vector3> verts = new List<Vector3>();
        List<Vector3> norms = new List<Vector3>();
        List<int> indices = new List<int>();
        List<Vector2> uv = new List<Vector2>();
        List<Color> colors = new List<Color>();


        for (int i = 0; i < 32; i++)
        {
            if ((patchesVisible & (1 << i)) == 0)
                continue;
            var tmp = new NURBS();
            for (int n = 0; n < 16; n++)
            {
                tmp[n] = Fix(m_Vertices[m_Patches[i][n] - 1]);
            }
            var patchVerts = tmp.SampleGrid(aUCount, aVCount);
            var patchIndices = NURBS.GenerateQuadIndices(aUCount, aVCount, verts.Count);
            var normals = tmp.SampleNormals(aUCount, aVCount);
            verts.AddRange(patchVerts);
            indices.AddRange(patchIndices);
            norms.AddRange(normals);
            colors.Capacity += patchVerts.Length;
            var c = new Color(Random.value * 0.5f, Random.value * 0.5f, Random.value * 0.5f, 1.0f);
            for (int n = 0; n < patchVerts.Length; n++)
            {
                colors.Add(c);
            }

            for (int v = 0; v < aVCount; v++)
                for (int u = 0; u < aUCount; u++)
                    uv.Add(new Vector2(u / (float)(aUCount - 1), v / (float)(aVCount - 1)));
        }
        m.Clear();
        vertCount = verts.Count;
        quadCount = indices.Count / 4;
        m.vertices = verts.ToArray();
        m.normals = norms.ToArray();
        m.uv = uv.ToArray();
        m.colors = colors.ToArray();
        m.SetIndices(indices.ToArray(), MeshTopology.Quads, 0);
        m.RecalculateBounds();
        drawQuadsWireframe = () =>
        {
            for (int i = 0; i < indices.Count / 4; i++)
            {
                var V1 = verts[indices[i * 4 + 0]] + norms[indices[i * 4 + 0]] * 0.01f;
                var V2 = verts[indices[i * 4 + 1]] + norms[indices[i * 4 + 1]] * 0.01f;
                var V3 = verts[indices[i * 4 + 2]] + norms[indices[i * 4 + 2]] * 0.01f;
                var V4 = verts[indices[i * 4 + 3]] + norms[indices[i * 4 + 3]] * 0.01f;
                GL.Vertex(V1); GL.Vertex(V2);
                GL.Vertex(V2); GL.Vertex(V3);
                GL.Vertex(V3); GL.Vertex(V4);
                GL.Vertex(V4); GL.Vertex(V1);
            }
        };
    }

    
    
    void Update ()
    {
        if (uCount != oldU || vCount != oldV || patchesVisible != oldPatchesVisible)
        {
            oldU = uCount;
            oldV = vCount;
            oldPatchesVisible = patchesVisible;
            GenerateTeapot(uCount, vCount);
        }
    }
    
    void OnGUI()
    {
        if (skin != null)
            GUI.skin = skin;
        GUILayout.BeginArea(new Rect(0,0,Screen.width, Screen.height));
        GUILayout.Space(10);
        
        GUILayout.BeginVertical();

        GUILayout.BeginHorizontal();
        GUILayout.Label("U resolution (" + uCount + ")", GUILayout.Width(120));
        uCount = (int)GUILayout.HorizontalSlider(uCount,2,20);
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        GUILayout.Label("V resolution (" + vCount + ")",GUILayout.Width(120));
        vCount = (int)GUILayout.HorizontalSlider(vCount,2,20);
        GUILayout.EndHorizontal();

        GUILayout.EndVertical();
        
        GUILayout.BeginVertical("box", GUILayout.Width(250));
        GUILayout.Label("Vertices: " + vertCount);
        GUILayout.Label("Quads: " + quadCount);
        GUILayout.EndVertical();

        GUILayout.BeginVertical("box",GUILayout.Width(250));
        for (int i = 0; i < config.Length; i++)
        {
            var c = config[i];
            GUILayout.BeginHorizontal();
            GUILayout.Label(c.Name);
            GUILayout.Space(10);
            for (int n = 0; n < c.patches.Length; n++ )
            {
                uint bit = (1u<<c.patches[n]);
                var b = GUILayout.Toggle((patchesVisible & bit) > 0u, "", "smallbutton");
                patchesVisible = (b) ? patchesVisible | bit : patchesVisible & (~bit);
            }
            GUILayout.EndHorizontal();
        }
        GUILayout.BeginHorizontal();
        GUILayout.Label("All");
        GUILayout.Space(10);
        if(GUILayout.Button("", "OnButton"))
        {
            patchesVisible = uint.MaxValue;
        }
        if(GUILayout.Button("", "OffButton"))
        {
            patchesVisible = 0;
        }
        GUILayout.EndHorizontal();

        GUILayout.EndVertical();

        GUILayout.BeginVertical("box", GUILayout.Width(250));

        GUILayout.BeginHorizontal();
        GUILayout.Label("material:");
        GUILayout.Space(10);
        for (int i = 0; i < materials.Count; i++)
        {
            if (GUILayout.Toggle(rend.sharedMaterial == materials[i], "", "smallbutton"))
                rend.sharedMaterial = materials[i];
        }
        GUILayout.EndHorizontal();
        GUILayout.Label(rend.sharedMaterial.name);

        GUILayout.BeginHorizontal();
        GUILayout.Label("wireframe:");
        GUILayout.Space(10);
        m_WireFrame = GUILayout.Toggle(m_WireFrame, "", "smallbutton");
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        GUILayout.Label("control:");
        GUILayout.Space(10);
        m_ShowControlPoints = GUILayout.Toggle(m_ShowControlPoints, "", "smallbutton");
        GUILayout.EndHorizontal();

        GUILayout.EndVertical();

        GUILayout.BeginVertical("box", GUILayout.Width(250));
        GUILayout.Label("left mouse to rotate teapot\nright mouse to rotate light\nscrollwheel to zoom");
        GUILayout.EndVertical();

        GUILayout.EndArea();

        if (Event.current.type == EventType.Repaint)
        {
            GL.PushMatrix();
            GL.Viewport(cam.pixelRect);
            GL.LoadProjectionMatrix(cam.projectionMatrix);
            GL.PushMatrix();
            GL.modelview = cam.worldToCameraMatrix * transform.localToWorldMatrix;
            if (m_WireFrame)
            {
                Drawing.BeginGL(new Color(0f,0.8f,0f,0.5f), GL.LINES, true);
                drawQuadsWireframe();
                GL.End();
            }
            if (m_ShowControlPoints)
            {
                Drawing.BeginGL(Color.red, GL.LINES, false);
                for (int i = 0; i < 32; i++)
                {
                    if ((patchesVisible & (1 << i)) == 0)
                        continue;
                    for (int n = 0; n < 4; n++)
                    {
                        Vector3 V1 = Fix(m_Vertices[m_Patches[i][ 0 + n] - 1]);
                        Vector3 V2 = Fix(m_Vertices[m_Patches[i][ 4 + n] - 1]);
                        Vector3 V3 = Fix(m_Vertices[m_Patches[i][ 8 + n] - 1]);
                        Vector3 V4 = Fix(m_Vertices[m_Patches[i][12 + n] - 1]);
                        GL.Vertex(V1); GL.Vertex(V2);
                        GL.Vertex(V2); GL.Vertex(V3);
                        GL.Vertex(V3); GL.Vertex(V4);
                        if(n<3)
                        {
                            Vector3 V1a = Fix(m_Vertices[m_Patches[i][0 + n+1] - 1]);
                            Vector3 V2a = Fix(m_Vertices[m_Patches[i][4 + n+1] - 1]);
                            Vector3 V3a = Fix(m_Vertices[m_Patches[i][8 + n+1] - 1]);
                            Vector3 V4a = Fix(m_Vertices[m_Patches[i][12 + n+1] - 1]);
                            GL.Vertex(V1); GL.Vertex(V1a);
                            GL.Vertex(V2); GL.Vertex(V2a);
                            GL.Vertex(V3); GL.Vertex(V3a);
                            GL.Vertex(V4); GL.Vertex(V4a);
                        }
                    }
                }
                GL.End();
            }
            // Draw coordinate system axes
            Drawing.BeginGL(Color.red, GL.LINES, false);
            GL.Vertex3(0,0,0);
            GL.Vertex3(1,0,0);
            GL.Color(Color.green);
            GL.Vertex3(0, 0, 0);
            GL.Vertex3(0, 1, 0);
            GL.Color(Color.blue);
            GL.Vertex3(0, 0, 0);
            GL.Vertex3(0, 0, 1);
            GL.End();
            GL.PopMatrix();

            // draw "sun ray" while rotating the light
            if (rotate == RotateMode.Light)
            {
                GL.PushMatrix();
                GL.modelview = cam.worldToCameraMatrix;
                Drawing.BeginGL(Color.yellow, GL.LINES, true);
                var dir = directionalLight.forward;
                GL.Vertex(Vector3.zero);
                GL.Vertex(-dir * 10000);
                GL.End();
                GL.PopMatrix();
            }
            GL.PopMatrix();
        }
        Event e = Event.current;
        if (rotate == RotateMode.None)
        {
            if (e.type == EventType.MouseDown)
            {
                if (e.button == 0)
                    rotate = RotateMode.Teapot;
                else if(e.button == 1)
                    rotate = RotateMode.Light;
            }
        }
        else if (rotate == RotateMode.Teapot)
        {
            if (e.type == EventType.MouseDrag)
            {
                var d = -e.delta*0.5f;
                transform.Rotate(Vector3.right, d.y,Space.World);
                transform.Rotate(Vector3.up, d.x, Space.World);

            }
        }
        else if (rotate == RotateMode.Light)
        {
            if (e.type == EventType.MouseDrag)
            {
                var d = -e.delta * 0.5f;
                directionalLight.Rotate(Vector3.right, d.y, Space.World);
                directionalLight.Rotate(Vector3.up, d.x, Space.World);
            }
        }

        if (e.type == EventType.MouseUp)
        {
            if (rotate == RotateMode.Teapot && e.button == 0)
                rotate = RotateMode.None;
            else if (rotate == RotateMode.Light && e.button == 1)
                rotate = RotateMode.None;
        }
        if (e.type == EventType.ScrollWheel)
        {
            cam.transform.position += Vector3.forward * e.delta.y*0.2f;
        }
    }
}