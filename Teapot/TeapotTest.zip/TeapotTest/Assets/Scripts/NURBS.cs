﻿using UnityEngine;
using System.Collections;

public class NURBS
{
    public struct Line
    {
        public Vector3 V1;
        public Vector3 V2;
        public Vector3 V3;
        public Vector3 V4;
        public Line(Vector3 aV1, Vector3 aV2, Vector3 aV3, Vector3 aV4)
        {
            V1 = aV1;
            V2 = aV2;
            V3 = aV3;
            V4 = aV4;
        }
        public Vector3 this[int aIndex]
        {
            get
            {
                switch (aIndex)
                {
                    case 0: return V1;
                    case 1: return V2;
                    case 2: return V3;
                    case 3: return V4;
                }
                throw new System.IndexOutOfRangeException();
            }
            set
            {
                switch (aIndex)
                {
                    case 0: V1 = value; return;
                    case 1: V2 = value; return;
                    case 2: V3 = value; return;
                    case 3: V4 = value; return;
                }
                throw new System.IndexOutOfRangeException();
            }
        }
        public Vector3 SampleBezier(float t)
        {
            return (((-V1 + 3 * (V2 - V3) + V4) * t + (3 * (V1 + V3) - 6 * V2)) * t + 3 * (V2 - V1)) * t + V1;
        }
        public Vector3 SampleBezierTangent(float t)
        {
            float tm = 1.0f - t;
            return (V2 - V1) * 3 * tm * tm + (V3 - V2) * 6 * tm * t + (V4 - V3) * 3 * t * t;
        }
    }
    public Line[] lines = new Line[4];
    public Vector3 this[int aIndex]
    {
        get
        {
            int line = aIndex / 4;
            if (line < 0 || line > 3)
                throw new System.IndexOutOfRangeException();
            return lines[line][aIndex % 4];
        }
        set
        {
            int line = aIndex / 4;
            if (line < 0 || line > 3)
                throw new System.IndexOutOfRangeException();
            lines[line][aIndex % 4] = value;
        }
    }

    public Vector3 Sample(float u, float v)
    {
        var tmp = SampleLineV(v);
        return tmp.SampleBezier(u);
    }
    public Vector3 SampleNormal(float u, float v)
    {
        var V = SampleLineV(v);
        var U = SampleLineU(u);
        var N = Vector3.Cross(U.SampleBezierTangent(v), V.SampleBezierTangent(u));
        return N.normalized;
    }
    public Line SampleLineV(float v)
    {
        Line result = new Line();
        result.V1 = lines[0].SampleBezier(v);
        result.V2 = lines[1].SampleBezier(v);
        result.V3 = lines[2].SampleBezier(v);
        result.V4 = lines[3].SampleBezier(v);
        return result;
    }
    public Line SampleLineU(float u)
    {
        Line L1 = new Line(lines[0].V1, lines[1].V1, lines[2].V1, lines[3].V1);
        Line L2 = new Line(lines[0].V2, lines[1].V2, lines[2].V2, lines[3].V2);
        Line L3 = new Line(lines[0].V3, lines[1].V3, lines[2].V3, lines[3].V3);
        Line L4 = new Line(lines[0].V4, lines[1].V4, lines[2].V4, lines[3].V4);
        Line result = new Line();
        result.V1 = L1.SampleBezier(u);
        result.V2 = L2.SampleBezier(u);
        result.V3 = L3.SampleBezier(u);
        result.V4 = L4.SampleBezier(u);
        return result;
    }
    public Vector3[] SampleGrid(int aUCount, int aVCount)
    {
        float uMul = 1.0f / (aUCount - 1);
        float vMul = 1.0f / (aVCount - 1);
        Vector3[] result = new Vector3[aUCount * aVCount];
        for (int v = 0; v < aVCount; v++)
        {
            var line = SampleLineV(v * vMul);
            for (int u = 0; u < aUCount; u++)
            {
                result[u + v * aUCount] = line.SampleBezier(u * uMul);
            }
        }
        return result;
    }

    public static int[] GenerateQuadIndices(int aXSize, int aYSize, int aOffset)
    {
        int[] result = new int[(aXSize - 1) * (aYSize - 1) * 4];
        int index = 0;
        for (int y = 0; y < aYSize - 1; y++)
        {
            for (int x = 0; x < aXSize - 1; x++)
            {
                result[index++] = aOffset + (x) + (y) * aXSize;
                result[index++] = aOffset + (x) + (y + 1) * aXSize;
                result[index++] = aOffset + (x + 1) + (y + 1) * aXSize;
                result[index++] = aOffset + (x + 1) + (y) * aXSize;
            }
        }
        return result;
    }

    public Vector3[] SampleNormals(int aUCount, int aVCount)
    {
        float uMul = 1.0f / (aUCount - 1);
        float vMul = 1.0f / (aVCount - 1);
        Vector3[] result = new Vector3[aUCount * aVCount];
        for (int v = 0; v < aVCount; v++)
        {
            var V = SampleLineV(v * vMul);
            for (int u = 0; u < aUCount; u++)
            {
                var U = SampleLineU(u * uMul);
                var U1 = U.SampleBezierTangent(v * vMul);
                var V1 = V.SampleBezierTangent(u * uMul);
                if (U1.sqrMagnitude == 0)
                {
                    var tmp = SampleLineV(1);
                    U1 = tmp.SampleBezierTangent(u * uMul);
                }
                if (V1.sqrMagnitude == 0)
                {
                    var tmp = SampleLineU(1);
                    V1 = tmp.SampleBezierTangent(v * vMul);
                }
                var N = Vector3.Cross(U1, V1);
                N.Normalize();
                //if (N.sqrMagnitude == 0)
                //    Debug.Log("Normal is 0: " +u + " / " + v);
                result[u + v * aUCount] = N.normalized;
            }
        }
        return result;
    }
}