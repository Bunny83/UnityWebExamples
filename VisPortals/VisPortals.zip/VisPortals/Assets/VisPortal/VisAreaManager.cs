﻿/******************************************************************************
 * The MIT License (MIT)
 * 
 * Copyright (c) 2016 Bunny83
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *****************************************************************************/
namespace B83.VisPortalSystem
{

    using UnityEngine;
    using System.Collections;
    using System.Collections.Generic;

    /// <summary>
    /// This class manages all VisAreas in the level. It fills in the areas automatically
    /// at Start. It also provides the main functionality to determine which areas are visible
    /// to a certain camera.
    /// </summary>
    public class VisAreaManager : MonoBehaviour
    {
        public List<VisArea> areas;
        private List<Plane> planes = new List<Plane>(6);
        private List<VisArea> areaClosedList = new List<VisArea>();
        public VisArea current = null;
        void Start()
        {
            areas = new List<VisArea>(FindObjectsOfType<VisArea>());
            for (int i = 0; i < areas.Count; i++)
            {
                foreach (var p in areas[i].portals)
                {
                    p.UpdatePlaneAndPoints();
                }
            }
        }
        // called once per frame before the camera renders the scene.
        public void DetermineVisibleAreas(Camera aCam)
        {
            Vector3 viewPos = aCam.transform.position;
            VisArea area = null;
            for (int i = 0; i < areas.Count; i++)
            {
                areas[i].isVisible = false;
                // find the starting area 
                if (area == null && areas[i].area.poly.IsPointInside(viewPos))
                    area = areas[i];
            }
            current = area;
            // if we can't determine the area we're in, activate all areas as fallback
            if (area == null)
            {
                for (int i = 0; i < areas.Count; i++)
                {
                    areas[i].isVisible = true;
                }
            }
            else
            {
                // we have a starting area so prepare the initial clipping planes
                planes.Clear();
                aCam.ReadFrustumPlanes(planes); // my extension that doesn't allocate a new array
                                                // remove near and far clipping plane
                planes.RemoveAt(5);
                planes.RemoveAt(4);
                areaClosedList.Clear();
                WalkThroughPortals(area, areaClosedList, planes, aCam);
            }

            // actually apply the visibility state of each area.
            for (int i = 0; i < areas.Count; i++)
            {
                areas[i].UpdateState();
            }
        }

        // walk recursively through the areas if there's a visible portal to them
        void WalkThroughPortals(VisArea aArea, List<VisArea> aClosed, List<Plane> aPlanes, Camera aCam)
        {
            aArea.isVisible = true;
            aClosed.Add(aArea);
            Vector3 viewPos = aCam.transform.position;
            int pCount = aArea.portals.Count;
            for (int i = 0; i < pCount; i++)
            {
                var p = aArea.portals[i];
                // signed distance of viewer from the portal plane
                float d = p.poly.plane.GetDistanceToPoint(viewPos);

                // ignore portals that don't face the viewer
                if (d < -0.1f)
                    continue;

                // ignore portals to areas we already checked to avoid endless recursion
                if (aClosed.Contains(p.IntoArea))
                    continue;

                // don't clip the poly if we're too close to avoid epsilon problems
                if (d < 1f)
                {
                    p.planes.Clear();
                    for (int n = 0; n < aPlanes.Count; n++)
                        p.planes.Add(aPlanes[n]);
                    WalkThroughPortals(p.IntoArea, aClosed, p.planes, aCam);
                    continue;
                }
                // clip the portal border to the current clipping planes

                var a = p.poly.Clip(aPlanes);
                if (p.clipped != null)
                    p.clipped.Return();
                p.clipped = a;
                if (a.points.Count > 2)
                {
                    p.planes.Clear();
                    // create new set of clipping planes based on the clipped portal border
                    a.CreateClippingPlanes(p.planes, viewPos);
                    WalkThroughPortals(p.IntoArea, aClosed, p.planes, aCam);
                }
            }
        }
    }
}