﻿/******************************************************************************
 * The MIT License (MIT)
 * 
 * Copyright (c) 2016 Bunny83
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *****************************************************************************/
namespace B83.VisPortalSystem
{

    using UnityEngine;
    using System.Collections;
    using System.Collections.Generic;

    /// <summary>
    /// This class defines a boundary shape in 3d which acts as a "portal" into another
    /// area. That area has to be linked with the "IntoArea" field. VisPortals belong to
    /// a certain VisArea and form the connection between two adjacent areas.
    /// 
    /// VisPortals usually come in pairs. One in Area1 that leads to Area2 and one in
    /// Area2 that leads back to Area1. The obviously have to face the opposite directions.
    /// </summary>
    public class VisPortal : PolyArea
    {
        public VisArea IntoArea;
        [System.NonSerialized]
        public List<Plane> planes = new List<Plane>();
        [System.NonSerialized]
        public Polygon clipped;
        public void Update()
        {
            UpdatePlaneAndPoints();
        }
        protected override void OnDrawGizmos()
        {
#if UNITY_EDITOR

            // If there is a latest clipped version of the polygon, draw that.
            if (clipped != null)
            {
                Camera cam = Camera.current;
                if (cam == null)
                    return;
                if (clipped.plane.GetDistanceToPoint(cam.transform.position) < -0.01f)
                    return;
                Gizmos.color = Color.yellow;
                for (int i = 0; i < clipped.points.Count; i++)
                {
                    int j = (i + 1) % clipped.points.Count;
                    Gizmos.DrawLine(clipped.points[i], clipped.points[j]);
                }
            }
            else
                base.OnDrawGizmos();
#endif
        }
        void OnDrawGizmosSelected()
        {
            // Draw a single line from the portal pivot to the target area
            // if this VisPortal is selected in the editor.
            if (IntoArea != null)
            {
                Gizmos.color = Color.cyan;
                if (IntoArea.area != null)
                    Gizmos.DrawLine(transform.position, IntoArea.area.transform.position);
                else
                    Gizmos.DrawLine(transform.position, IntoArea.transform.position);
            }
        }
    }
}