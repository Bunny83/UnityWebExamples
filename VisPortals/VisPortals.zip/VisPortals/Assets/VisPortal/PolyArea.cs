﻿/******************************************************************************
 * The MIT License (MIT)
 * 
 * Copyright (c) 2016 Bunny83
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *****************************************************************************/
namespace B83.VisPortalSystem
{

    using UnityEngine;
    using System.Collections;
    using System.Collections.Generic;

    /// <summary>
    /// Defines an arbitrary 2d polygon inside the 3d space. It can be used to specify an
    /// area by tracing the boundary of the area. This is the base class for the VisPortal
    /// 
    /// This class has a custom editor which allows editing the vertices similar to a
    /// PolygonCollider2D but you can rotate the object to re-orient the plane in which the
    /// polygon lives. The objects forward vector is used as plane normal. So the forward
    /// vector has to face you in order to see the front. Furthermore if has to have a
    /// clockwise winding. The editor has a "reverse" button. Just hold down "CTRL" when a
    /// PolyArea or VisPortal is selected.
    /// 
    /// Note: the editor uses FreeMoveHandles which can be vertex snapped to "some degree".
    /// Since the points are defined in a 2d plane that plane would have to touch the surface
    /// to which you want the handles snapped to. In case you don't know: press and hold "v"
    /// for Unity's vertex snapping while moving a handle.
    /// 
    /// </summary>
    public class PolyArea : MonoBehaviour
    {
        public List<Vector2> points;
        public Polygon poly = Polygon.Create();
        void Awake()
        {
            UpdatePlaneAndPoints();
        }

        public void UpdatePlaneAndPoints()
        {

            poly.plane = new Plane(transform.forward, transform.position);
            poly.points.Clear();
            for (int i = 0; i < points.Count; i++)
            {
                poly.points.Add(transform.TransformPoint(points[i]));
            }
        }

        protected virtual void OnDrawGizmos()
        {
#if UNITY_EDITOR

            Camera cam = Camera.current;
            if (cam == null)
                return;
            UpdatePlaneAndPoints();
            Vector3 dir = transform.position - cam.transform.position;
            float d = Vector3.Dot(poly.plane.normal, dir);
            Gizmos.color = (d > 0) ? Color.red : Color.green;
            for (int i = 0; i < poly.points.Count; i++)
            {
                int j = (i + 1) % poly.points.Count;
                Gizmos.DrawLine(poly.points[i], poly.points[j]);
            }
            if (UnityEditor.Selection.activeGameObject != gameObject)
                Gizmos.DrawIcon(transform.position, "");
#endif
        }

    }

    /// <summary>
    /// Represents a 2d polygon in 3d.
    /// </summary>
    public class Polygon
    {
        #region Pool
        // A pool implementation that uses a simple one-directional linked list
        // implemented threadsafe to allow an automatic finalizer "Return()"
        // Since the finalizer is called from the GC thread we need a lock
        private static Polygon m_Pool = null;
        private static object m_PoolLock = new object();
        private Polygon m_NextPool = null;
        // Get an instance, either from the pool or create a new instance
        public static Polygon Create(Polygon aSource = null)
        {
            Polygon p = null;
            if (m_Pool != null)
            {
                lock (m_PoolLock)
                {
                    if (m_Pool != null)
                    {
                        p = m_Pool;
                        m_Pool = p.m_NextPool;
                    }
                }
            }
            if (p == null)
                p = new Polygon();
            if (aSource != null)
            {
                if (p.points.Capacity < aSource.points.Count)
                    p.points.Capacity = aSource.points.Count;
                for (int i = 0; i < aSource.points.Count; i++)
                {
                    p.points.Add(aSource.points[i]);
                }
                p.plane = aSource.plane;
            }
            return p;
        }
        // return an instance to the object pool
        public static void Return(Polygon aPolygon)
        {
            aPolygon.points.Clear();
            lock (m_PoolLock)
            {
                aPolygon.m_NextPool = m_Pool;
                m_Pool = aPolygon;
            }
        }
        public void Return()
        {
            Return(this);
        }
        // Just to automatically put objects back into the pool that weren't returned propertly
        ~Polygon()
        {
            Return();
            // this is important to reactivate the finalizer so it can be auto-collected again
            System.GC.ReRegisterForFinalize(this);
        }
        #endregion Pool
        private static List<float> m_Dists = new List<float>();

        public List<Vector3> points = new List<Vector3>();
        public Plane plane;

        /// <summary>
        /// clips the polygon at the given plane and returns a new version
        /// </summary>
        public Polygon Clip(Plane aPlane, float aEpsilon = 0.1f)
        {
            var res = Polygon.Create();
            res.plane = plane;
            m_Dists.Clear();
            int count = points.Count;
            if (m_Dists.Capacity < count)
                m_Dists.Capacity = count;
            for (int i = 0; i < count; i++)
            {
                Vector3 p = points[i];
                m_Dists.Add(aPlane.GetDistanceToPoint(p));
            }
            for (int i = 0; i < count; i++)
            {
                int j = (i + 1) % count;
                float d1 = m_Dists[i];
                float d2 = m_Dists[j];
                Vector3 p1 = points[i];
                Vector3 p2 = points[j];
                bool split = d1 > aEpsilon;
                if (split)
                {
                    res.points.Add(p1);
                }
                else if (d1 > -aEpsilon)
                {
                    // point on clipping plane so just keep it
                    res.points.Add(p1);
                    continue;
                }
                // both points are on the same side of the plane
                if ((d2 > -aEpsilon && split) || (d2 < aEpsilon && !split))
                {
                    continue;
                }
                float d = d1 / (d1 - d2);
                res.points.Add(p1 + (p2 - p1) * d);
            }
            return res;
        }

        /// <summary>
        /// clips the polygon at the given planes and returns a new version
        /// </summary>
        public Polygon Clip(List<Plane> aPlanes, float aEpsilon = 0.1f)
        {
            var res = Create(this); // create a duplicate which can be returned to the pool when done
            for (int i = 0; i < aPlanes.Count; i++)
            {
                var clippedPoly = res.Clip(aPlanes[i], aEpsilon);
                Return(res); // return the old instance to the pool
                res = clippedPoly;
            }
            return res;
        }

        /// <summary>
        /// Returns "true" if "aPoint" is inside the polygon. The polygon winding
        /// does matter. A clockwise polygon
        /// </summary>
        public bool IsPointInside(Vector3 aPoint)
        {
            int count = points.Count;
            if (count < 3)
                return false;
            var mid = (points[0] + points[1]) * 0.5f;
            // !! due to a bug in the Plane constructor we have to manually normalize the normal vector!!
            Plane t = new Plane(Vector3.Cross(plane.normal, mid - aPoint).normalized, aPoint);
            Plane t2 = new Plane(Vector3.Cross(plane.normal, t.normal).normalized, aPoint);
            int wc = 0;
            int j = points.Count - 1;
            for (int i = 0; i < points.Count; j = i++)
            {
                var p1 = points[i];
                var p2 = points[j];
                var d1 = t.GetDistanceToPoint(p1);
                var d2 = t.GetDistanceToPoint(p2);
                // only check edges which cross the "t" plane
                if (d1 > 0 == d2 > 0)
                    continue;
                float d = d1 / (d1 - d2);
                var intersect = p1 + (p2 - p1) * d;
                if (!t2.GetSide(intersect))
                    continue;
                var dir = p1 - p2;
                var v = aPoint - p2;
                v = Vector3.Cross(dir, v);
                if (plane.GetSide(v))
                    wc++;
                else
                    wc--;
            }
            return wc % 2 == 1;
        }

        /// <summary>
        /// Creates a clipping plane for every edge of the polygon that goes through
        /// aViewPos and adds them to the list. If polygon winding order is clockwise
        /// the plane normals point inward and create a view frustum. If they are
        /// counter clockwise the plane normals would point outwards
        /// </summary>
        public void CreateClippingPlanes(List<Plane> aList, Vector3 aViewPos)
        {
            int count = points.Count;
            for (int i = 0; i < count; i++)
            {
                int j = (i + 1) % count;
                var p1 = points[i];
                var p2 = points[j];
                var n = Vector3.Cross(p1 - p2, aViewPos - p2);
                var l = n.magnitude;
                if (l < 0.01f)
                    continue;
                aList.Add(new Plane(n / l, aViewPos));
            }
        }
    }
}