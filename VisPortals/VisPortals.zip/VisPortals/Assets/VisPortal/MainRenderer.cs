﻿/******************************************************************************
 * The MIT License (MIT)
 * 
 * Copyright (c) 2016 Bunny83
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *****************************************************************************/
namespace B83.VisPortalSystem
{
    using UnityEngine;

    /// <summary>
    /// This class currently renders everything. The cameras are disabled and rendered manually
    /// in the right order. It also calls "VisAreaManager.DetermineVisibleAreas" for the main camera
    /// </summary>
    public class MainRenderer : MonoBehaviour
    {
        public static bool debugDraw;
        public Camera mainCam;
        public Camera overviewCam;
        public VisAreaManager visManager;
        public Material lineMat;
        Rect v1_Pos;
        Rect v2_Pos;
        CamViewArea v1;
        CamViewArea v2;
        CamView main;
        CamView overview;
        VisArea currentArea;
        void Start()
        {
            v1_Pos = new Rect(0, 0, Screen.width, Screen.height);
            v2_Pos = new Rect(5, 70, 200, 200);
            main = new CamView(mainCam, "Main view");
            main.OnFinishedDrawing += OnDrawMainOverlay;
            overview = new CamView(overviewCam, "overview");
            overview.OnFinishedDrawing += OnDrawOverviewOverlay;
            v1 = new CamViewArea(main);
            v2 = new CamViewWindow(overview);
        }
        void OnGUI()
        {
            v1_Pos = new Rect(0, 0, Screen.width, Screen.height);
            if (Event.current.type == EventType.Repaint)
                visManager.DetermineVisibleAreas(mainCam);
            currentArea = visManager.current;

            // draw the fullscreen view
            v1.Draw(v1_Pos);
            // draw the window view
            v2_Pos = v2.Draw(v2_Pos);

            if (GUILayout.Button("swap views"))
            {
                // swap main and overview content.
                var tmp = v1.content;
                v1.content = v2.content;
                v2.content = tmp;
            }
            debugDraw = GUILayout.Toggle(debugDraw, "debug Draw", "button");
            if (currentArea != null)
                GUILayout.Label("Current Area: " + currentArea.name);
        }
        void OnDrawOverviewOverlay(CamView aView)
        {
            Event e = Event.current;
            if (e.type == EventType.Repaint && debugDraw)
            {
                GL.PushMatrix();
                GL.Viewport(aView.screenSpaceRect);
                GL.modelview = aView.cam.worldToCameraMatrix;
                GL.LoadProjectionMatrix(aView.cam.projectionMatrix);
                lineMat.SetPass(0);
                var p = mainCam.transform.position;
                GL.Begin(GL.LINES);
                GL.Color(Color.red);
                GL.Vertex(p);
                GL.Vertex(mainCam.ViewportToWorldPoint(new Vector3(0, 1, 1000)));
                GL.Vertex(p);
                GL.Vertex(mainCam.ViewportToWorldPoint(new Vector3(1, 1, 1000)));
                GL.Vertex(p);
                GL.Vertex(mainCam.ViewportToWorldPoint(new Vector3(0, 0, 1000)));
                GL.Vertex(p);
                GL.Vertex(mainCam.ViewportToWorldPoint(new Vector3(1, 0, 1000)));
                GL.End();

                GL.PopMatrix();
            }
        }
        void OnDrawMainOverlay(CamView aView)
        {
            Event e = Event.current;
            if (e.type == EventType.Repaint && debugDraw)
            {
                GL.PushMatrix();
                GL.Viewport(aView.screenSpaceRect);
                GL.modelview = aView.cam.worldToCameraMatrix;
                GL.LoadProjectionMatrix(aView.cam.projectionMatrix);
                lineMat.SetPass(0);
                GL.Begin(GL.TRIANGLES);
                var viewPos = mainCam.transform.position;
                foreach (var a in visManager.areas)
                {
                    if (!a.isVisible)
                        continue;
                    foreach (var portal in a.portals)
                    {
                        if (portal.poly == null)
                            continue;
                        if (portal.poly.plane.GetDistanceToPoint(viewPos) < 0)
                            continue;
                        var p = portal.poly.points;
                        if (p.Count < 3)
                            continue;
                        var s = p[0];
                        GL.Color(new Color(1, 1, 0, 0.2f));
                        for (int i = 1; i < p.Count - 1; i++)
                        {
                            GL.Vertex(s);
                            GL.Vertex(p[i]);
                            GL.Vertex(p[i + 1]);
                        }
                    }
                }
                GL.End();
                GL.PopMatrix();
            }
        }
    }

    /// <summary>
    /// Represents a certain camera view. It provides the final screen rect that is used
    /// and might call a delegate after rendering
    /// </summary>
    public class CamView
    {
        public Camera cam;
        public string title;
        public Rect screenSpaceRect;
        public event System.Action<CamView> OnFinishedDrawing;

        public CamView(Camera aCam, string aTitle)
        {
            cam = aCam;
            title = aTitle;
            cam.enabled = false;
        }

        public virtual Rect Draw(Rect aPos)
        {
            Event e = Event.current;
            if (e.type == EventType.Repaint)
            {
                screenSpaceRect = aPos;
                screenSpaceRect.y = Screen.height - screenSpaceRect.height - screenSpaceRect.y;
                cam.pixelRect = screenSpaceRect;
                cam.Render();
            }
            if (OnFinishedDrawing != null)
                OnFinishedDrawing(this);
            return aPos;
        }
    }

    /// <summary>
    /// A container class that can hold a CamView.
    /// </summary>
    public class CamViewArea
    {
        public CamView content;
        public CamViewArea(CamView aContent)
        {
            content = aContent;
        }
        public virtual Rect Draw(Rect aPos)
        {
            return content.Draw(aPos);
        }

    }

    /// <summary>
    /// A specialized container which is drawn into a GUI window.
    /// </summary>
    public class CamViewWindow : CamViewArea
    {
        private static int m_LastID = 0;
        private int m_ID = m_LastID++;
        private Rect m_Pos;
        private Rect m_ContentRect;
        public CamViewWindow(CamView aContent) : base(aContent) { }

        public override Rect Draw(Rect aPos)
        {
            m_Pos = aPos;
            m_Pos = GUI.Window(m_ID, m_Pos, OnDraw, content.title);
            return m_Pos;
        }
        private void OnDraw(int aId)
        {
            GUI.DragWindow(new Rect(0, 0, 10000, 15));
            m_ContentRect = GUILayoutUtility.GetRect(10, 10000, 10, 10000);
            m_ContentRect.position += m_Pos.position;
            base.Draw(m_ContentRect);
        }

    }
}