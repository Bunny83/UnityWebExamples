﻿/******************************************************************************
 * The MIT License (MIT)
 * 
 * Copyright (c) 2016 Bunny83
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *****************************************************************************/
namespace B83.VisPortalSystem
{
    using UnityEngine;
    using UnityEditor;
    using System.Collections.Generic;


    [CustomEditor(typeof(PolyArea), true)]
    public class VisPortalEditor : Editor
    {
        private static int m_HandleHash = "FreeMoveHandleHash".GetHashCode();
        PolyArea area;
        bool edit = false;
        bool editPivot = false;
        void OnEnable()
        {
            area = (PolyArea)target;
            if (area.points == null)
                area.points = new List<Vector2>();
            area.UpdatePlaneAndPoints();
        }
        void OnDisable()
        {
            if (edit)
                Tools.current = Tool.Move;
            edit = false;
            editPivot = false;
        }
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
        }
        public void OnSceneGUI()
        {
            int backId = GUIUtility.GetControlID(FocusType.Keyboard);
            int moveHandleID = -1;

            if (Tools.current != Tool.None)
            {
                edit = false;
                editPivot = false;
            }
            // prevent deselection while editing
            if (edit)
                HandleUtility.AddDefaultControl(backId);
            Event e = Event.current;
            while (area.points.Count < 3)
                area.points.Add(new Vector2(0, 0));
            int count = area.points.Count;
            var t = area.transform;
            Plane plane = new Plane(t.forward, t.position);
            var rot = t.rotation;
            var center = Vector3.zero;
            for (int i = 0; i < count; i++)
            {
                int j = i + 1;
                if (j >= count)
                    j = 0;
                Vector3 p = t.TransformPoint(area.points[i]);
                center += p;
                if (edit)
                {
                    Vector3 p2 = t.TransformPoint(area.points[j]);
                    if (!e.control)
                    {
                        var newP = MyPlaneMoveHandle(p, rot, plane);
                        if (newP != p)
                        {
                            area.points[i] = t.InverseTransformPoint(newP);
                        }
                        // "Hack" to get the controlID that the "Handles.FreeMoveHandle" allocates internally
                        moveHandleID = GUIUtility.GetControlID(m_HandleHash, FocusType.Keyboard) - 1;
                    }
                    Handles.color = Color.green;
                    Handles.DrawLine(p, p2);
                    var dir = (p2 - p);
                    if (dir.sqrMagnitude < 0.001f)
                        dir = area.poly.plane.normal;
                    if (e.control)
                    {
                        var centerPos = (p + p2) / 2f;
                        Handles.BeginGUI();
                        Rect rect = GetSceneViewRect(new Rect(0, 0, 30, 30), centerPos);
                        var oldColor = GUI.color;
                        GUI.color = Color.green;
                        if (GUI.Button(rect, "N"))
                        {
                            area.points.Insert(i + 1, t.InverseTransformPoint(centerPos));
                            GUIUtility.ExitGUI();
                        }
                        rect = GetSceneViewRect(new Rect(0, 0, 30, 30), p);
                        GUI.color = Color.red;
                        if (GUI.Button(rect, "X"))
                        {
                            area.points.RemoveAt(i);
                            GUIUtility.ExitGUI();
                        }
                        GUI.color = oldColor;
                        Handles.EndGUI();
                    }
                    float size = HandleUtility.GetHandleSize(p + dir * 0.3f) * 0.2f;
                    Handles.ConeCap(GUIUtility.GetControlID(FocusType.Passive), p + dir * 0.3333333f, Quaternion.LookRotation(dir), size);
                    size = HandleUtility.GetHandleSize(p + dir * 0.6f) * 0.2f;
                    Handles.ConeCap(GUIUtility.GetControlID(FocusType.Passive), p + dir * 0.6666666f, Quaternion.LookRotation(dir), size);
                }
                if (e.rawType == EventType.KeyDown && e.keyCode == KeyCode.Delete && GUIUtility.keyboardControl == moveHandleID)
                {
                    e.Use();
                    area.points.RemoveAt(i);
                    GUIUtility.ExitGUI();
                }
            }
            if (editPivot)
            {
                // allows to move the transform around the plane without moving the polygon points
                var newPivot = MyPlaneMoveHandle(t.position, rot, plane);
                if (newPivot != t.position)
                {
                    Vector3 delta = newPivot - t.position;
                    t.position = newPivot;
                    for (int i = 0; i < count; i++)
                    {
                        Vector3 p = t.TransformPoint(area.points[i]);
                        area.points[i] = t.InverseTransformPoint(p - delta);
                    }
                }
            }
            center /= area.points.Count;
            Handles.BeginGUI();
            Rect r = GetSceneViewRect(new Rect(0, 0, 80, 30), center);
            if (e.control)
            {
                r.y -= 40;
                if (GUI.Button(r, edit ? "Stop Editing" : "Edit"))
                {
                    edit = !edit;
                    if (edit)
                        Tools.current = Tool.None;
                    else
                        Tools.current = Tool.Move;
                    SceneView.currentDrawingSceneView.Repaint();
                }
                if (edit)
                {
                    r.y += 31;
                    if (GUI.Button(r, editPivot ? "fix pivot" : "Edit Pivot"))
                    {
                        editPivot = !editPivot;
                    }
                }
                r.y += 31;
                if (GUI.Button(r, "Reverse"))
                {
                    area.points.Reverse();
                }
            }
            else
                GUI.Label(r, "Hold CTRL");

            if (editPivot)
                GUI.Label(GetSceneViewRect(new Rect(0, 0, 35, 50), t.position), "pivot");

            Handles.EndGUI();
        }

        /// <summary>
        /// Projects a world point into GUI space inside the current sceneview.
        /// </summary>
        Vector2 GetSceneViewPos(Vector3 aWorldPos)
        {
            var pos = SceneView.currentDrawingSceneView.camera.WorldToScreenPoint(aWorldPos);
            pos.y = SceneView.currentDrawingSceneView.camera.pixelHeight - pos.y;
            return pos;
        }
        /// <summary>
        /// Centers a screenspace rect around a projected world point.
        /// </summary>
        Rect GetSceneViewRect(Rect r, Vector3 aWorldPos)
        {
            r.center = GetSceneViewPos(aWorldPos);
            return r;
        }

        /// <summary>
        /// Handles.FreeMoveHandle allows dragging in 3d. It moves the point on a plane
        /// that is parallel to the screen (near or far clip plane). However we only
        /// want to allow movement inside a particular plane. So we first let Unity
        /// move in 3d and then we use the new point to project back onto our plane.
        /// </summary>
        Vector3 MyPlaneMoveHandle(Vector3 pos, Quaternion rot, Plane plane)
        {
            var newP = Handles.FreeMoveHandle(pos, rot, HandleUtility.GetHandleSize(pos) * 0.1f, Vector3.zero, Handles.RectangleCap);
            if (newP != pos)
            {
                Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
                ray.direction = (newP - ray.origin).normalized;
                float dist;
                if (plane.Raycast(ray, out dist))
                {
                    pos = ray.GetPoint(dist);
                }
            }
            return pos;
        }
    }
}