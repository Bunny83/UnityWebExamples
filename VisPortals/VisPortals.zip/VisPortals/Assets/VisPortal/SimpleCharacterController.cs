﻿/******************************************************************************
 * The MIT License (MIT)
 * 
 * Copyright (c) 2016 Bunny83
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *****************************************************************************/
namespace B83.VisPortalSystem
{
    using UnityEngine;

    public class SimpleCharacterController : MonoBehaviour
    {
        CharacterController controller;
        public Transform head;
        public float speed = 5;
        public float mspeed = 5;
        float pitch;

        void Awake()
        {
            controller = GetComponent<CharacterController>();
        }

        void Update()
        {
            float fwd = Input.GetAxis("Vertical");
            float right = Input.GetAxis("Horizontal");
            Vector3 movement = fwd * transform.forward + right * transform.right;
            controller.Move(movement * Time.deltaTime * speed);
            float mx = Input.GetAxis("Mouse X");
            float my = Input.GetAxis("Mouse Y");
            if (Input.GetMouseButtonDown(1))
            {
                Cursor.lockState = CursorLockMode.Locked;
            }
            if (Input.GetMouseButtonUp(1))
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }

            if (Input.GetMouseButton(1))
            {
                transform.Rotate(0, mx * mspeed, 0);
                pitch -= my * mspeed;
                pitch = Mathf.Clamp(pitch, -89.8f, 89.8f);
                head.localEulerAngles = new Vector3(pitch, 0, 0);
            }
        }
    }
}